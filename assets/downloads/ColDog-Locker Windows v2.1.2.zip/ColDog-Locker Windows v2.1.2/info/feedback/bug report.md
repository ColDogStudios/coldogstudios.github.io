---
name: Bug report
about: Create a report to help us improve
---

**Desktop (please complete the following information):**
 - OS: [e.g. Windows 11]

**Describe the bug**
A clear and concise description of what the bug is.

**To Reproduce**
Steps to reproduce the behavior:
1. Open '...'
2. Enter '....'
3. See error

**Expected behavior**
A clear and concise description of what you expected to happen.

**Screenshots**
If applicable, add screenshots to help explain your problem.

**Additional context**
Add any other context about the problem here.

**Google Form**:
https://forms.gle/E1gX7A972udKL7SC6
